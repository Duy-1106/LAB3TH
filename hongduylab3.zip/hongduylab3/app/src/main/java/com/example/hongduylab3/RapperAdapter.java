package com.example.hongduylab3;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.view.LayoutInflater;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class RapperAdapter extends BaseAdapter {

    Context context;
    ArrayList<RapperItem> list;

    public RapperAdapter(Context c, ArrayList<RapperItem> l) {
        context = c;
        list = l;
    }

    @Override
    public int getCount() { return list.size(); }

    @Override
    public Object getItem(int i) { return list.get(i); }

    @Override
    public long getItemId(int i) { return i; }

    @Override
    public View getView(int i, View view, ViewGroup parent) {

        view = LayoutInflater.from(context).inflate(R.layout.grid_item, parent, false);

        ImageView img = view.findViewById(R.id.imgAvatar);
        TextView name = view.findViewById(R.id.tvName);
        TextView score = view.findViewById(R.id.tvScore);

        RapperItem item = list.get(i);

        img.setImageResource(item.img);
        name.setText(item.name);
        score.setText(item.score);

        return view;
    }
}
