package com.example.hongduylab3;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public class CurrencySpinnerAdapter extends ArrayAdapter<String> {

    private final Context context;
    private final String[] units;
    private final String[] names;
    private final int[] flags;

    public CurrencySpinnerAdapter(@NonNull Context context,
                                  String[] units,
                                  String[] names,
                                  int[] flags) {
        super(context, 0, units);
        this.context = context;
        this.units = units;
        this.names = names;
        this.flags = flags;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView,
                        @NonNull ViewGroup parent) {
        return createItem(position, convertView, parent);
    }

    @Override
    public View getDropDownView(int position, @Nullable View convertView,
                                @NonNull ViewGroup parent) {
        return createItem(position, convertView, parent);
    }

    private View createItem(int position, View convertView, ViewGroup parent) {
        View view = convertView;
        if (view == null) {
            view = LayoutInflater.from(context)
                    .inflate(R.layout.item_currency, parent, false);
        }
        ImageView imgFlag = view.findViewById(R.id.img_flag);
        TextView tvCurrency = view.findViewById(R.id.tv_currency);

        imgFlag.setImageResource(flags[position]);
        String text = units[position] + " - " + names[position];
        tvCurrency.setText(text);

        return view;
    }
}
