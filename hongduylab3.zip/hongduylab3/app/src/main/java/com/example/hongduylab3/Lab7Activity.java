package com.example.hongduylab3;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Window;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Lab7Activity extends AppCompatActivity {

    Button btnToast, btnDialog, btnOpenColor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lab7);

        btnToast = findViewById(R.id.btnToast);
        btnDialog = findViewById(R.id.btnDialog);
        btnOpenColor = findViewById(R.id.btnOpenColor); // nút mở ChooseColor

        // Nút TOAST
        btnToast.setOnClickListener(v -> showCustomToast());

        // Nút DIALOG
        btnDialog.setOnClickListener(v -> showLoginDialog());

        // Nút CHOOSE COLOR
        btnOpenColor.setOnClickListener(v -> {
            Intent i = new Intent(Lab7Activity.this, ColorActivity.class);
            startActivity(i);
        });
    }

    // ======== CUSTOM TOAST ========
    private void showCustomToast() {
        LayoutInflater inflater = getLayoutInflater();
        View layout = inflater.inflate(R.layout.toast_custom, null);

        Toast toast = new Toast(getApplicationContext());
        toast.setDuration(Toast.LENGTH_SHORT);
        toast.setView(layout);
        toast.setGravity(Gravity.CENTER_HORIZONTAL | Gravity.CENTER_VERTICAL, 0, -50);
        toast.show();
    }

    // ======== CUSTOM DIALOG LOGIN ========
    private void showLoginDialog() {
        Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_login);

        EditText edtUser = dialog.findViewById(R.id.edtUser);
        EditText edtPass = dialog.findViewById(R.id.edtPass);
        Button btnOk = dialog.findViewById(R.id.btnOk);
        Button btnCancel = dialog.findViewById(R.id.btnCancel);

        edtUser.setText("admin");
        edtPass.setText("123456");

        btnCancel.setOnClickListener(v -> dialog.dismiss());

        btnOk.setOnClickListener(v -> {
            String u = edtUser.getText().toString().trim();
            if ("admin".equals(u)) {
                Toast.makeText(Lab7Activity.this,
                        "Đăng nhập: " + u, Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(Lab7Activity.this,
                        "Sai tài khoản", Toast.LENGTH_SHORT).show();
            }
            dialog.dismiss();
        });

        dialog.show();
    }
}
