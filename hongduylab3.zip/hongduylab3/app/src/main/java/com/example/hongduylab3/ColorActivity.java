package com.example.hongduylab3;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.widget.SeekBar;
import android.widget.TextView;
import android.view.View;

public class ColorActivity extends AppCompatActivity {

    private SeekBar sbR, sbG, sbB;
    private TextView tvR, tvG, tvB;
    private View viewRgb, viewCmy;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_color);

        sbR = findViewById(R.id.sbR);
        sbG = findViewById(R.id.sbG);
        sbB = findViewById(R.id.sbB);

        tvR = findViewById(R.id.tvR);
        tvG = findViewById(R.id.tvG);
        tvB = findViewById(R.id.tvB);

        viewRgb = findViewById(R.id.viewRgb);
        viewCmy = findViewById(R.id.viewCmy);

        sbR.setMax(255);
        sbG.setMax(255);
        sbB.setMax(255);

        // giá trị khởi tạo cho giống ví dụ
        sbR.setProgress(26);
        sbG.setProgress(168);
        sbB.setProgress(16);

        SeekBar.OnSeekBarChangeListener listener = new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                updateColor();
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) { }
            @Override public void onStopTrackingTouch(SeekBar seekBar) { }
        };

        sbR.setOnSeekBarChangeListener(listener);
        sbG.setOnSeekBarChangeListener(listener);
        sbB.setOnSeekBarChangeListener(listener);

        updateColor();
    }

    private void updateColor() {
        int r = sbR.getProgress();
        int g = sbG.getProgress();
        int b = sbB.getProgress();

        tvR.setText("R = " + r);
        tvG.setText("G = " + g);
        tvB.setText("B = " + b);

        int rgb = Color.rgb(r, g, b);
        viewRgb.setBackgroundColor(rgb);

        // CMY: c = 255 - r ...
        int c = 255 - r;
        int m = 255 - g;
        int y = 255 - b;
        int cmy = Color.rgb(c, m, y);
        viewCmy.setBackgroundColor(cmy);
    }
}
