package com.example.hongduylab3;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;
import java.util.ArrayList;

public class Lab8ListActivity extends AppCompatActivity {

    ListView lvFood;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lab8_list);

        lvFood = findViewById(R.id.lvFood);

        ArrayList<FoodItem> list = new ArrayList<>();

        int img = R.drawable.ic_launcher_foreground;

        list.add(new FoodItem(img, "Hamburger", "Bánh mì kẹp thịt tròn", "Giá:12.000đ"));
        list.add(new FoodItem(img, "Bánh mì", "Bánh mì kẹp thịt", "Giá:12.000đ"));
        list.add(new FoodItem(img, "Bánh bao", "Nhân thịt trứng", "Giá:10.000đ"));
        list.add(new FoodItem(img, "Bánh ú", "Dùng cho tế lễ", "Giá:5.000đ"));
        list.add(new FoodItem(img, "Bánh giò chay", "Nếp hoặc tẻ", "Giá:6.000đ"));
        list.add(new FoodItem(img, "Bánh giò thịt", "Nếp nhân thịt", "Giá:8.000đ"));

        FoodAdapter adapter = new FoodAdapter(this, list);
        lvFood.setAdapter(adapter);
    }
}
