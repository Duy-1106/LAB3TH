package com.example.hongduylab3;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.Locale;

public class MoneyListAdapter extends BaseAdapter {

    private final Context context;
    private final String[] units;
    private final int[] flags;
    private final double[] values;
    private final LayoutInflater inflater;

    public MoneyListAdapter(Context context,
                            String[] units,
                            int[] flags,
                            double[] values) {
        this.context = context;
        this.units = units;
        this.flags = flags;
        this.values = values;
        this.inflater = LayoutInflater.from(context);
    }

    @Override
    public int getCount() {
        return units.length;
    }

    @Override
    public Object getItem(int position) {
        return values[position];
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View view = convertView;
        if (view == null) {
            view = inflater.inflate(R.layout.item_money_row, parent, false);
        }

        ImageView imgFlag = view.findViewById(R.id.img_flag_row);
        TextView tvCode = view.findViewById(R.id.tv_code_row);
        TextView tvValue = view.findViewById(R.id.tv_value_row);

        imgFlag.setImageResource(flags[position]);
        tvCode.setText(units[position]);

        String text = String.format(Locale.US, "%.6f", values[position]);
        tvValue.setText(text);

        return view;
    }
}
