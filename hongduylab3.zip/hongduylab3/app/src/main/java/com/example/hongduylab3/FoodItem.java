package com.example.hongduylab3;

public class FoodItem {
    public int imageRes;
    public String name, desc, priceText;

    public FoodItem(int imageRes, String name, String desc, String priceText) {
        this.imageRes = imageRes;
        this.name = name;
        this.desc = desc;
        this.priceText = priceText;
    }
}
