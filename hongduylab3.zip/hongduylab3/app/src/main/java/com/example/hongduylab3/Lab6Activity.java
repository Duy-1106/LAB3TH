package com.example.hongduylab3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Button;

public class Lab6Activity extends AppCompatActivity {

    EditText edtMoney;
    Spinner spCurrency;
    ListView lvMoney;
    Button btnOpenLength;

    double[][] rate = {
            {1,    0.93, 0.80, 1.48, 1.36, 18.2, 1.67, 150, 83, 24300},
            {1.07, 1,    0.86, 1.59, 1.46, 19.6, 1.80, 161, 90, 26000},
            {1.25, 1.16, 1,    1.85, 1.70, 22.8, 2.10, 188, 105, 30000},
            {0.67, 0.63, 0.54, 1,    0.92, 12.3, 1.13, 102, 57, 16200},
            {0.73, 0.68, 0.59, 1.08, 1,    13.4, 1.24, 112, 63, 18000},
            {0.055,0.051,0.044,0.081,0.074,1,    0.092, 8.3, 4.7, 1350},
            {0.60, 0.55, 0.48, 0.88, 0.80, 10.8, 1,    93,  52, 15000},
            {0.0067,0.0062,0.0053,0.0098,0.0089,0.12, 0.0107,1, 0.56,161},
            {0.012,0.011,0.0095,0.017,0.015,0.21, 0.018,1.8,1,  290},
            {0.000041,0.000038,0.000033,0.000062,0.000055,0.00074,0.000067,0.0062,0.0034,1}
    };

    String[] units;
    String[] names;
    int[] flags;
    double[] values;
    MoneyListAdapter listAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lab6);

        edtMoney = findViewById(R.id.edtMoney);
        spCurrency = findViewById(R.id.spCurrency);
        lvMoney = findViewById(R.id.lvMoney);
        btnOpenLength = findViewById(R.id.btnOpenLength);

        units = new String[]{
                getString(R.string.usd_unit),
                getString(R.string.eur_unit),
                getString(R.string.gbp_unit),
                getString(R.string.aud_unit),
                getString(R.string.cad_unit),
                getString(R.string.zar_unit),
                getString(R.string.nzd_unit),
                getString(R.string.jpy_unit),
                getString(R.string.inr_unit),
                getString(R.string.vnd_unit)
        };

        names = new String[]{
                getString(R.string.usd_name),
                getString(R.string.eur_name),
                getString(R.string.gbp_name),
                getString(R.string.aud_name),
                getString(R.string.cad_name),
                getString(R.string.zar_name),
                getString(R.string.nzd_name),
                getString(R.string.jpy_name),
                getString(R.string.inr_name),
                getString(R.string.vnd_name)
        };

        flags = new int[]{
                R.drawable.flag_usd,
                R.drawable.flag_eur,
                R.drawable.flag_gbp,
                R.drawable.flag_aud,
                R.drawable.flag_cad,
                R.drawable.flag_zar,
                R.drawable.flag_nzd,
                R.drawable.flag_jpy,
                R.drawable.flag_inr,
                R.drawable.flag_vnd
        };

        CurrencySpinnerAdapter spinnerAdapter =
                new CurrencySpinnerAdapter(this, units, names, flags);
        spCurrency.setAdapter(spinnerAdapter);

        values = new double[units.length];
        listAdapter = new MoneyListAdapter(this, units, flags, values);
        lvMoney.setAdapter(listAdapter);

        spCurrency.setOnItemSelectedListener(
                new android.widget.AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(android.widget.AdapterView<?> parent,
                                               android.view.View view, int position, long id) {
                        updateMoneyList();
                    }

                    @Override
                    public void onNothingSelected(android.widget.AdapterView<?> parent) { }
                });

        edtMoney.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                updateMoneyList();
            }
            @Override public void afterTextChanged(Editable s) {}
        });

        btnOpenLength.setOnClickListener(v -> {
            Intent intent = new Intent(Lab6Activity.this, LengthActivity.class);
            startActivity(intent);
        });
    }

    private void updateMoneyList() {
        String text = edtMoney.getText().toString().trim();

        if (text.isEmpty()) {
            for (int i = 0; i < values.length; i++) values[i] = 0;
            listAdapter.notifyDataSetChanged();
            return;
        }

        double amount;
        try {
            amount = Double.parseDouble(text);
        } catch (NumberFormatException e) {
            for (int i = 0; i < values.length; i++) values[i] = 0;
            listAdapter.notifyDataSetChanged();
            return;
        }

        int from = spCurrency.getSelectedItemPosition();

        for (int i = 0; i < values.length; i++) {
            values[i] = amount * rate[from][i];
        }

        listAdapter.notifyDataSetChanged();
    }
}
