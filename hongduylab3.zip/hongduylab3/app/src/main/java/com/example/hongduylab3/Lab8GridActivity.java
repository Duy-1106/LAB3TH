package com.example.hongduylab3;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.GridView;

import java.util.ArrayList;

public class Lab8GridActivity extends AppCompatActivity {

    GridView gridView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lab8_grid);

        gridView = findViewById(R.id.gridRapper);

        ArrayList<RapperItem> list = new ArrayList<>();
        int img = R.drawable.ic_launcher_foreground;

        list.add(new RapperItem(img, "Maboo", "283,297"));
        list.add(new RapperItem(img, "SameOldShawn", "252,433"));
        list.add(new RapperItem(img, "Magnitude901", "164,935"));
        list.add(new RapperItem(img, "Brandon", "100,466"));
        list.add(new RapperItem(img, "Clement_RGF", "93,932"));

        RapperAdapter adapter = new RapperAdapter(this, list);
        gridView.setAdapter(adapter);
    }
}
