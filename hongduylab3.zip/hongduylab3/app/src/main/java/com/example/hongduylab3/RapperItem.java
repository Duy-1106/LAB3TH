package com.example.hongduylab3;

public class RapperItem {
    int img;
    String name, score;

    public RapperItem(int img, String name, String score) {
        this.img = img;
        this.name = name;
        this.score = score;
    }
}
