package com.example.hongduylab3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.ArrayAdapter;

import java.util.ArrayList;
import java.util.Locale;

public class LengthActivity extends AppCompatActivity {

    EditText edtLength;
    Spinner spUnit;
    ListView lvResult;

    String[] unitNames = {
            "Hải lý", "Dặm", "Kilometer", "Lý", "Met", "Yard", "Foot", "Inches"
    };

    // 1 đơn vị tương ứng bao nhiêu mét
    double[] toMeter = {
            1852.0,     // Hải lý
            1609.344,   // Dặm
            1000.0,     // Km
            500.0,      // Lý
            1.0,        // Mét
            0.9144,     // Yard
            0.3048,     // Foot
            0.0254      // Inches
    };

    ArrayList<String> resultList;
    ArrayAdapter<String> listAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_length);

        edtLength = findViewById(R.id.edtLength);
        spUnit = findViewById(R.id.spUnit);
        lvResult = findViewById(R.id.lvResult);

        // Adapter cho Spinner
        ArrayAdapter<String> spinAdapter =
                new ArrayAdapter<>(this,
                        android.R.layout.simple_spinner_item, unitNames);
        spinAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spUnit.setAdapter(spinAdapter);

        // Adapter cho ListView
        resultList = new ArrayList<>();
        listAdapter = new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1, resultList);
        lvResult.setAdapter(listAdapter);

        // Lắng nghe chọn đơn vị trong Spinner
        spUnit.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(android.widget.AdapterView<?> parent,
                                       android.view.View view,
                                       int position,
                                       long id) {
                updateResult();
            }

            @Override
            public void onNothingSelected(android.widget.AdapterView<?> parent) { }
        });

        // Lắng nghe thay đổi text trong EditText
        edtLength.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                updateResult();
            }
            @Override public void afterTextChanged(Editable s) {}
        });
    }

    private void updateResult() {
        String text = edtLength.getText().toString().trim();
        resultList.clear();

        if (text.isEmpty()) {
            listAdapter.notifyDataSetChanged();
            return;
        }

        double value;
        try {
            value = Double.parseDouble(text);
        } catch (NumberFormatException e) {
            listAdapter.notifyDataSetChanged();
            return;
        }

        int fromIndex = spUnit.getSelectedItemPosition();
        double inMeter = value * toMeter[fromIndex];

        for (int i = 0; i < unitNames.length; i++) {
            double converted = inMeter / toMeter[i];
            String line = String.format(Locale.US, "%.4f    %s", converted, unitNames[i]);
            resultList.add(line);
        }

        listAdapter.notifyDataSetChanged();
    }
}
