package com.example.hongduylab3;

import android.content.Context;
import android.view.*;
import android.widget.*;

import java.util.ArrayList;

public class FoodAdapter extends BaseAdapter {

    Context context;
    ArrayList<FoodItem> data;

    public FoodAdapter(Context ctx, ArrayList<FoodItem> list) {
        context = ctx;
        data = list;
    }

    @Override
    public int getCount() { return data.size(); }

    @Override
    public Object getItem(int position) { return data.get(position); }

    @Override
    public long getItemId(int position) { return position; }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        if (convertView == null) {
            convertView = LayoutInflater.from(context)
                    .inflate(R.layout.item_food, parent, false);
        }

        FoodItem item = data.get(position);

        ImageView img = convertView.findViewById(R.id.imgFood);
        TextView tvName = convertView.findViewById(R.id.tvName);
        TextView tvDesc = convertView.findViewById(R.id.tvDesc);
        TextView tvPrice = convertView.findViewById(R.id.tvPrice);

        img.setImageResource(item.imageRes);
        tvName.setText(item.name);
        tvDesc.setText(item.desc);
        tvPrice.setText(item.priceText);

        return convertView;
    }
}
