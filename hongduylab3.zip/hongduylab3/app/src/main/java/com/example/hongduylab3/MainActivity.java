package com.example.hongduylab3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    Button btnLab6, btnLab7, btnLab8;
    TextView tvMenuTitle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvMenuTitle = findViewById(R.id.tvMenuTitle);
        btnLab6 = findViewById(R.id.btnLab6);
        btnLab7 = findViewById(R.id.btnLab7);
        btnLab8 = findViewById(R.id.btnLab8);   // <-- mới thêm

        btnLab6.setOnClickListener(v -> {
            startActivity(new Intent(MainActivity.this, Lab6Activity.class));
        });

        btnLab7.setOnClickListener(v -> {
            startActivity(new Intent(MainActivity.this, Lab7Activity.class));
        });

        // 👉 Nút Lab 8
        btnLab8.setOnClickListener(v -> {
            startActivity(new Intent(MainActivity.this, Lab8Activity.class));
        });
    }
}
